"""**17**"""
def optimal_license_order(rates):
    # Создаем список кортежей (индекс, скорость роста)
    indexed_rates = [(i + 1, rates[i]) for i in range(len(rates))]

    # Сортируем по убыванию скорости роста
    indexed_rates.sort(key=lambda x: x[1], reverse=True)

    # Извлекаем порядок индексов
    order = [item[0] for item in indexed_rates]

    # Вычисляем общую стоимость
    total_cost = 0.0
    for month, (_, r) in enumerate(indexed_rates):
        cost = 100.0 * (r ** month)
        total_cost += cost

    return order, total_cost


if __name__ == "__main__":
    rates = [1.5, 2.0, 1.1, 1.8, 1.3]

    order, total = optimal_license_order(rates)

    print(f"Скорости роста: {rates}\nОптимальный порядок покупки (индексы лицензий): {order}\nМинимальная общая стоимость: ${total:.2f}")

    # Сравнение с неправильным порядком
    wrong_order = sorted([(i+1, rates[i]) for i in range(len(rates))],
                         key=lambda x: x[1])
    wrong_total = sum(100.0 * (r ** month) for month, (_, r) in enumerate(wrong_order))
    print(f"\nДля сравнения, если продавать в обратном порядке: ${wrong_total:.2f}")
    print(f"Разница в пользу оптимального порядка: ${wrong_total - total:.2f}")

"""**17(2)**"""

def optimal_sale_order(rates):
    # Создаем список кортежей (индекс, коэффициент)
    indexed_rates = [(i + 1, rates[i]) for i in range(len(rates))]

    # Сортируем по возрастанию скорости роста
    indexed_rates.sort(key=lambda x: x[1])

    # Извлекаем порядок индексов
    order = [item[0] for item in indexed_rates]

    # Вычисляем общую стоимость
    total_revenue = 0.0
    for month, (_, r) in enumerate(indexed_rates):
        revenue = 100.0 * (r ** month)
        total_revenue += revenue

    return order, total_revenue


if __name__ == "__main__":
    rates = [0.8, 0.3, 0.9, 0.5]

    order, total = optimal_sale_order(rates)

    print(f"Скорости роста: {rates}\nОптимальный порядок покупки (индексы лицензий): {order}\nМинимальная общая стоимость: ${total:.2f}")

    # Сравнение с неправильным порядком
    wrong_order = sorted([(i+1, rates[i]) for i in range(len(rates))],
                         key=lambda x: x[1], reverse=True)
    wrong_total = sum(100.0 * (r ** month) for month, (_, r) in enumerate(wrong_order))
    print(f"\nДля сравнения, если продавать в обратном порядке: ${wrong_total:.2f}")
    print(f"Разница в пользу оптимального порядка: ${total - wrong_total:.2f}")
